#! /bin/bash

function show_help {
    echo "Uso: $0 [ORIGEN] [DESTINO]"
    echo "Realiza un backup del directorio ORIGEN al directorio DESTINO"
    echo "Opciones:"
    echo "  -h, --help    Mostrar esta ayuda"
}

if [[ $1 == "-h" || $1 == "--help" ]]; then
    show_help
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Error: Se requieren dos argumentos: ORIGEN y DESTINO"
    show_help
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen $ORIGEN no existe o no está montado"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino $DESTINO no existe o no está montado"
    exit 1
fi

FECHA=$(date +%Y%m%d)

case "$ORIGEN" in
    "/etc")
        NOMBRE_BKP="etc_bkp_$FECHA.tar.gz"
        ;;
    "/var/logs")
        NOMBRE_BKP="logs_bkp_$FECHA.tar.gz"
        ;;
    "/www_dir")
        NOMBRE_BKP="www_bkp_$FECHA.tar.gz"
        ;;
    "/db_dir")
        NOMBRE_BKP="db_bkp_$FECHA.tar.gz"
        ;;
    *)
        echo "Error: Directorio de origen no reconocido"
        exit 1
        ;;
esac

tar -czf "$DESTINO/$NOMBRE_BKP" -C "$ORIGEN" .

if [ $? -eq 0 ]; then
    echo "Backup de $ORIGEN creado exitosamente en $DESTINO/$NOMBRE_BKP"
else
    echo "Error: No se pudo crear el backup de $ORIGEN"
    exit 1
fi
